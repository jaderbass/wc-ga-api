<div class="flex item-center space-x-4">
  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" width="32px" height="32px" version="1.0" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 91.73 91.73">
    <defs>
      <style type="text/css">
        .fil1 {
          fill: #F49C0F
        }

        .fil2 {
          fill: #636566
        }

        .fil0 {
          fill: white
        }
      </style>
    </defs>
    <g id="Ebene_x0020_1">
      <metadata id="CorelCorpID_0Corel-Layer"></metadata>
      <g id="_2892959691696">
        <circle class="fil0" cx="45.87" cy="45.87" r="45.87"></circle>
        <g>
          <path class="fil1" d="M45.86 10.16l-16.22 33.44 32.45 0 -16.23 -33.44z"></path>
          <path class="fil2" d="M45.86 81.57l-16.22 -33.43 32.45 0 -16.23 33.43z"></path>
        </g>
      </g>
    </g>
  </svg>
  &nbsp;<?php echo e(config('app.name')); ?>

</div><?php /**PATH C:\laragon\www\myProjects\wc-ga-api\resources\views/components/filament-brand-logo.blade.php ENDPATH**/ ?>